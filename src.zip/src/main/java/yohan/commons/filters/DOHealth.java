package yohan.commons.filters;

/**
 *
 * @author yohanr
 */
public class DOHealth {

    long time;

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
