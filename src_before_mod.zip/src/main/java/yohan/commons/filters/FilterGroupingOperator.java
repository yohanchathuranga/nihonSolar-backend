
package yohan.commons.filters;

/**
 *
 * @author yohanr
 */
public enum FilterGroupingOperator {
    OR, AND
}
