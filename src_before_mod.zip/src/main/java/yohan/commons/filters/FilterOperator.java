
package yohan.commons.filters;

/**
 *
 * @author yohanr
 */
public enum FilterOperator {
    LIKE,
    EQUAL,
    NOT_EQUAL,
    LESS_THAN,
    GREATER_THAN,
    NOT_LIKE
}
