/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nihon.entity;

/**
 *
 * @author yohan
 */
public class DOClearanceCollectedDate {
    private String clearanceId;
    private long collectedDate;

    public String getClearanceId() {
        return clearanceId;
    }

    public void setClearanceId(String clearanceId) {
        this.clearanceId = clearanceId;
    }

    public long getCollectedDate() {
        return collectedDate;
    }

    public void setCollectedDate(long collectedDate) {
        this.collectedDate = collectedDate;
    }
    
}
