package com.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 *
 * @author yohan
 */

public class DOListCountResult {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    
}
