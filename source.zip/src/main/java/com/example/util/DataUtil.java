/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.util;

/**
 *
 * @author yohan
 */
public class DataUtil {

    public static String USER_STATE_NEW = "NEW";
    public static String USER_STATE_REGISTERD = "REGISTERED";

    public static String USER_TYPE_EMPLOYEE = "EMPLOYEE";
    public static String USER_TYPE_CUSTOMER = "CUSTOMER";
    public static String USER_TYPE_ADMIN = "ADMIN";

    public static String PROJECT_STATE_NEW = "NEW";
    public static String PROJECT_STATE_PENDING = "PENDING";
    public static String PROJECT_STATE_APPROVED = "APPROVED";
    public static String PROJECT_STATE_CANCELLED = "CANCELLED";

    public static String QUOTATION_STATE_NEW = "NEW";
    public static String QUOTATION_STATE_PENDING = "PENDING";
    public static String QUOTATION_STATE_FINALIZED = "FINALIZED";
    public static String QUOTATION_STATE_DISCARD = "DISCARD";

    public static String FEEDBACK_STATE_NEW = "NEW";
    public static String FEEDBACK_STATE_RECIEVED = "RECIEVED";

    public static String STATE_NEW = "NEW";
    public static String STATE_CANCELLED = "CANCELLED";

    public static String NOTIFICATION_STATE_NEW = "NEW";
    public static String NOTIFICATION_STATE_SENT = "SENT";
    public static String NOTIFICATION_STATE_FAILED = "FAILED";

    public static String STATUS_CHECK_STATE_NEW = "NEW";
    public static String STATUS_CHECK_STATE_CHECKED = "CHECKED";

    public static String TIME_ZONE = "Asia/Colombo";
}
